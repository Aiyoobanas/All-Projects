<html>
<head>
<link rel="shortcut icon" type="image/x-icon" href="images/ambulance1.png" />
</head>
</html>