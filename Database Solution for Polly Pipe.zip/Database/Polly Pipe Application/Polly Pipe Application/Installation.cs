﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Polly_Pipe_Application
{
    public partial class Installation : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=AIYOOB;Initial Catalog=DBpollypipe;Integrated Security=True");

        public Installation()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            mainmenu mm = new mainmenu();
            mm.Visible = true;
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into INSTALLATION values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + dateTimePicker1.Value.ToString() + "','" + dateTimePicker2.Value.ToString() + "','" + textBox4.Text + "','" + textBox5.Text + "')";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    disp_data();
                    MessageBox.Show("Record inserted successfully");
                }
                else
                {
                    MessageBox.Show("Please Provide Details!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            
        }
        public void disp_data()
        {
            
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from INSTALLATION";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            
           
        }

        private void Installation_Load(object sender, EventArgs e)
        {
            disp_data();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            { 
            if (textBox1.Text != "")
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from INSTALLATION where installation_id='" + textBox1.Text + "'";
                cmd.ExecuteReader();
                con.Close();
                disp_data();
                MessageBox.Show("Record deleted successfully");
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

}

        private void button2_Click(object sender, EventArgs e)
        {
            try { 

            if (textBox1.Text != "")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update INSTALLATION set installation_address='" + textBox2.Text + "', installation_type='" + textBox3.Text + "', customer_id='" + textBox4.Text + "',fac_id='" + textBox5.Text + "',starting_date='" + dateTimePicker1.Value.ToString() + "',ending_date='" + dateTimePicker2.Value.ToString() + "' where installation_id='" + textBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Updated Successfully.");
                con.Close();
                disp_data();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
           
        }
    }
    
}
