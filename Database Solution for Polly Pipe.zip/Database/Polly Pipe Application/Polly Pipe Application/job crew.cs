﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Polly_Pipe_Application
{

    public partial class job_crew : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=AIYOOB;Initial Catalog=DBpollypipe;Integrated Security=True");
        public job_crew()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            mainmenu mm = new mainmenu();
            mm.Visible = true;
            this.Hide();
        }

        private void job_crew_Load(object sender, EventArgs e)
        {
            disp_data();
        }
        public void disp_data()
        {

            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from JOB_CREW2";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "" )
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into JOB_CREW2 values('" + textBox1.Text + "','" + textBox2.Text + "')";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    disp_data();
                    MessageBox.Show("Record inserted successfully");
                }
                else
                {
                    MessageBox.Show("Please Provide Details!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "")
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "delete from JOB_CREW2 where installation_id='" + textBox1.Text + "'";
                    cmd.ExecuteReader();
                    con.Close();
                    disp_data();
                    MessageBox.Show("Record deleted successfully");
                }
                else
                {
                    MessageBox.Show("Please Provide Details!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
    }
}
