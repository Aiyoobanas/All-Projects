﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polly_Pipe_Application
{
    public partial class log : Form
    {
        public log()
        {
            InitializeComponent();
        }

        private void loginbutton_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "admin" && textBox2.Text == "123")
            {
                MessageBox.Show("Login successful");
                mainmenu mm = new mainmenu();
                mm.Visible = true;
                this.Hide();
               

            }
            else
            {

                MessageBox.Show("Login Fail! Please re-try!");

            }
        }

        private void L_Load(object sender, EventArgs e)
        {

        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            
                DialogResult dr = MessageBox.Show("Do you want to exit.", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    Application.ExitThread();
                }
                else
                { }
            
        }
    }
}
