﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polly_Pipe_Application
{
    public partial class mainmenu : Form
    {
        public mainmenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Customer mm = new Customer();
            mm.Visible = true;
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Equipment mm = new Equipment();
            mm.Visible = true;
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Installation mm = new Installation();
            mm.Visible = true;
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Staff mm = new Staff();
            mm.Visible = true;
            this.Hide();

        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string message = "Do you want to Logout?";
            string title = "Close Window";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                log mm = new log();
                mm.Visible = true;
                this.Hide();
            }
            else
            {
              
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Facility mm = new Facility();
            mm.Visible = true;
            this.Hide();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            job_crew mm = new job_crew();
            mm.Visible = true;
            this.Hide();
        }
    }
}
